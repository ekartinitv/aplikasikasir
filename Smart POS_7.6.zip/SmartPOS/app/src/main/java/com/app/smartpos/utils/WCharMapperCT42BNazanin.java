package com.app.smartpos.utils;

public class WCharMapperCT42BNazanin extends WCharMapperCT41{


}
